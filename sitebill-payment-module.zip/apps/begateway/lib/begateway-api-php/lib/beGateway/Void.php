<?php
namespace beGateway;

class Void extends ChildTransaction {
}
?>
